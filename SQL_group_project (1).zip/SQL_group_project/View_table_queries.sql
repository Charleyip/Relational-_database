USE `user094_DB3`;

CREATE VIEW View_GamesLocations AS
SELECT g.GameDate, l.StadiumName, l.City, l.State
FROM Games g
JOIN Locations l ON g.LocationID = l.LocationID
ORDER BY g.GameDate DESC;

CREATE VIEW View_MVPsTeams AS
SELECT g.GameDate, g.MVP, t.TeamName
FROM Games g
JOIN Players p ON g.MVP = p.PlayerName
JOIN Teams t ON p.TeamID = t.TeamID
ORDER BY g.GameDate DESC;

CREATE VIEW View_LatestTeamGame AS
SELECT t.TeamName, MAX(g.GameDate) AS LatestGameDate
FROM Teams t
JOIN TeamGame tg ON t.TeamID = tg.TeamID
JOIN Games g ON tg.GameID = g.GameID
GROUP BY t.TeamName
ORDER BY LatestGameDate DESC;

CREATE VIEW View_TopPlayersYards AS
SELECT p.PlayerName, gp.YardsGained, gp.GameID
FROM GamePerformance gp
JOIN Players p ON gp.PlayerID = p.PlayerID
ORDER BY gp.YardsGained DESC
LIMIT 5;

CREATE VIEW View_TeamAppearances AS
SELECT t.TeamName, COUNT(tg.GameID) AS NumberOfAppearances
FROM Teams t
JOIN TeamGame tg ON t.TeamID = tg.TeamID
GROUP BY t.TeamName
ORDER BY NumberOfAppearances DESC;

CREATE VIEW View_TotalPointsByTeam AS
SELECT t.TeamName, SUM(tg.Scores) AS TotalPoints
FROM TeamGame tg
JOIN Teams t ON tg.TeamID = t.TeamID
GROUP BY t.TeamName
ORDER BY TotalPoints DESC;

CREATE VIEW View_PlayersGames AS
SELECT p.PlayerName, p.Position, g.GameDate
FROM Players p
JOIN GamePerformance gp ON p.PlayerID = gp.PlayerID
JOIN Games g ON gp.GameID = g.GameID
ORDER BY g.GameDate DESC, p.PlayerName;
