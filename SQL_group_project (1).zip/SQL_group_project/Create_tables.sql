CREATE DATABASE IF NOT EXISTS `user094_DB3`;
USE `user094_DB3`;
DROP TABLE IF EXISTS Locations;
DROP TABLE IF EXISTS Teams;
DROP TABLE IF EXISTS Players;
DROP TABLE IF EXISTS Games;
DROP TABLE IF EXISTS GamePerformance;
DROP TABLE IF EXISTS TeamGame;
-- Table: Locations
CREATE TABLE  `Locations` (
    `LocationID` INT AUTO_INCREMENT PRIMARY KEY,
    `StadiumName` VARCHAR(25) NOT NULL,
    `City` VARCHAR(255) NOT NULL,
    `State` VARCHAR(100) NOT NULL,
    `Capacity` INT NOT NULL
) ENGINE=InnoDB;


-- Table: Teams
CREATE TABLE  `Teams` (
    `TeamID` INT AUTO_INCREMENT PRIMARY KEY,
    `TeamName` VARCHAR(255) NOT NULL,
    `TeamCity` VARCHAR(255) NOT NULL
) ENGINE=InnoDB;




-- Table: Players
CREATE TABLE  `Players` (
    `PlayerID` INT AUTO_INCREMENT PRIMARY KEY,
    `PlayerName` VARCHAR(255) NOT NULL,
    `TeamID` INT NOT NULL,
    `Position` VARCHAR(50) NOT NULL,
    `Birthdate` DATE NOT NULL,
    `JerseyNumber` INT NOT NULL CHECK (`JerseyNumber` BETWEEN 0 AND 99),
    `Weight` INT NOT NULL CHECK (`Weight` >= 50 AND `Weight` <= 400),
    `Height` DECIMAL(5,2) NOT NULL CHECK (`Height` >= 1.50 AND `Height` <= 2.50),
    FOREIGN KEY (`TeamID`) REFERENCES `Teams`(`TeamID`)
) ENGINE=InnoDB;

-- Table: Games
CREATE TABLE  `Games` (
    `GameID` INT AUTO_INCREMENT PRIMARY KEY,
    `GameDate` DATE NOT NULL,
    `LocationID` INT NOT NULL,
    `MVP` VARCHAR(25),
    `SeasonYear` INT NOT NULL CHECK (`SeasonYear` >= 1967),
    `IsOvertime` BOOL NOT NULL DEFAULT FALSE,
    `TotalAttendance` INT, 
    FOREIGN KEY (`LocationID`) REFERENCES `Locations`(`LocationID`)
) ENGINE=InnoDB;



-- Table: TeamGame
CREATE TABLE  `TeamGame` (
    `TeamGameID` INT AUTO_INCREMENT PRIMARY KEY,
    `GameID` INT NOT NULL,
    `TeamID` INT NOT NULL,
    `Scores` INT NOT NULL,
    FOREIGN KEY (`GameID`) REFERENCES `Games`(`GameID`),
    FOREIGN KEY (`TeamID`) REFERENCES `Teams`(`TeamID`)
) ENGINE=InnoDB;


-- Table: GamePerformance
CREATE TABLE  `GamePerformance` (
    `PerformanceID` INT AUTO_INCREMENT PRIMARY KEY,
    `GameID` INT NOT NULL,
    `PlayerID` INT NOT NULL,
    `PointsScored` INT,
    `YardsGained` DECIMAL(10,2),
    `PlayTime` TIME NOT NULL,
    FOREIGN KEY (`GameID`) REFERENCES `Games`(`GameID`),
    FOREIGN KEY (`PlayerID`) REFERENCES `Players`(`PlayerID`)
) ENGINE=InnoDB;

