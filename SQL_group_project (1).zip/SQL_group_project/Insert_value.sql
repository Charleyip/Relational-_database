
-- Completing Games table with 10 entries
-- Completing Locations table with 10 entries
INSERT INTO Locations (StadiumName, City, State, Capacity) VALUES
('Liberty Stadium', 'Liberty City', 'Freedom', 80000),
('Eagle Stadium', 'Eagle City', 'Pride', 75000),
('Falcon Arena', 'Falcon City', 'Courage', 72000),
('Hawk Dome', 'Hawk Town', 'Valor', 68000),
('Condor Field', 'Condor City', 'Spirit', 70000),
('Raptor Park', 'Raptorville', 'Vigor', 69000),
('Sparrow Grounds', 'Sparrow City', 'Honor', 71000),
('Vulture Nest', 'Vulture Town', 'Glory', 73000),
('Osprey Stadium', 'Osprey City', 'Majesty', 74000),
('Kite Arena', 'Kite Town', 'Triumph', 76000);

-- Completing Teams table with 10 entries
INSERT INTO Teams (TeamName, TeamCity) VALUES
('Eagles', 'Eagle City'),
('Ravens', 'Raven Town'),
('Falcons', 'Falcon City'),
('Hawks', 'Hawk Town'),
('Condors', 'Condor City'),
('Raptors', 'Raptorville'),
('Sparrows', 'Sparrow City'),
('Vultures', 'Vulture Town'),
('Ospreys', 'Osprey City'),
('Kites', 'Kite Town');

-- Completing Players table with 10 entries
INSERT INTO Players (PlayerName, TeamID, Position, Birthdate, JerseyNumber, Weight, Height) VALUES
('John Stellar', 1, 'Quarterback', '1992-08-15', 12, 215, 1.88),
('Alex Runner', 2, 'Running Back', '1994-03-22', 22, 195, 1.82),
('Chris Catcher', 3, 'Wide Receiver', '1989-11-09', 18, 210, 1.85),
('Mike Tackler', 4, 'Linebacker', '1990-06-01', 52, 230, 1.90),
('Victor S.', 5, 'Tight End', '1988-12-05', 85, 250, 1.92),
('Evan Runner', 6, 'Running Back', '1993-07-30', 28, 190, 1.80),
('Oliver Hurdler', 7, 'Safety', '1991-04-18', 33, 205, 1.88),
('Liam Rusher', 8, 'Defensive End', '1992-02-14', 96, 275, 1.96),
('Noah Kicker', 9, 'Kicker', '1995-08-19', 9, 180, 1.78),
('Logan Punter', 10, 'Punter', '1987-03-25', 4, 190, 1.82);

INSERT INTO Games (GameDate, LocationID, MVP, SeasonYear, IsOvertime, TotalAttendance) VALUES
('2024-02-03', 1, 'John Stellar', 2023, FALSE, 80000),
('2023-02-05', 2, 'Alex Runner', 2022, TRUE, 75000),
('2022-02-06', 3, NULL, 2021, FALSE, 70000),
('2021-02-07', 4, 'Chris Catcher', 2020, FALSE, 68000),
('2020-02-02', 5, 'Mike Tackler', 2019, FALSE, 72000),
('2019-02-03', 6, NULL, 2018, TRUE, 75000),
('2018-02-04', 7, 'Victor S.', 2017, FALSE, 77000),
('2017-02-05', 8, 'Evan Runner', 2016, FALSE, 81000),
('2016-02-07', 9, 'Oliver Hurdler', 2015, TRUE, 80000),
('2015-02-01', 10, 'Liam Rusher', 2014, FALSE, 83000);



-- Completing GamePerformance table with 10 entries
INSERT INTO GamePerformance (GameID, PlayerID, PointsScored, YardsGained, PlayTime) VALUES
(1, 1, 21, 300.5, '01:15:00'),
(2, 2, 14, 120.0, '00:45:00'),
(3, 3, 7, 80.0, '00:30:00'),
(4, 4, 0, 0.0, '01:00:00'),
(5, 5, 10, 150.2, '01:10:00'),
(6, 6, 21, 175.5, '01:20:00'),
(7, 7, 14, 90.3, '00:40:00'),
(8, 8, 7, 110.0, '00:50:00'),
(9, 9, 3, 0.0, '00:15:00'),
(10, 10, 0, 0.0, '00:35:00');

-- Completing TeamGame table with 10 entries
INSERT INTO TeamGame (GameID, TeamID, Scores) VALUES
(1, 1, 31),
(1, 2, 28),
(2, 3, 33),
(2, 4, 27),
(3, 5, 24),
(3, 6, 21),
(4, 7, 30),
(4, 8, 31),
(5, 9, 17),
(5, 10, 14);



SELECT * FROM Games;
